from .cow_face import transparent_sticker

__all__ = ["transparent_sticker"]
